<script setup>

</script>

<template>
  <main>
    <h1 class="text 3xl">Mr Barber</h1>
  </main>
</template>
