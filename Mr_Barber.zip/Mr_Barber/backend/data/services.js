export const services = [
    {
        name:"Corte Clasico",
        price:"160"
    },
    {
        name:"Corte Moderno",
        price:"180"
    },
    {
        name:"Corte Empleado",
        price:"130"
    },
    {
        name:"Corte Clásico Jr.",
        price:"120"
    },
    {
        name:"Corte Tijera y/o Moderno Jr.",
        price:"130"
    },
    {
        name:"Limpieza de Corte",
        price:"80"
    },
    {
        name:"Rasurado Completo",
        price:"160"
    },
    {
        name:"Delineado de Barba",
        price:"150"
    },
    {
        name:"Tinte Bigote Candado",
        price:"100"
    },
    {
        name:"Tinte de Barba",
        price:"160"
    },
    {
        name:"Tinte de Cabello Completo",
        price:"250"
    },
    {
        name:"Mascarilla Negra",
        price:"100"
    },
    {
        name:"Facial Express",
        price:"150"
    },
    {
        name:"Facial Profundo",
        price:"300"
    }
]